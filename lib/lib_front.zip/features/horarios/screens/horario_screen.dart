import 'package:flutter/material.dart';
import '../../../core/theme/theme.dart';

class HorarioScreen extends StatelessWidget {
  const HorarioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isMobile =
        MediaQuery.of(context).size.width < 700;

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: isMobile ? 18 : 40,
            vertical: 24,
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.center,
            children: [
              // Header
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color:
                      AppTheme.primary,
                  borderRadius:
                      BorderRadius.circular(
                    24,
                  ),
                ),
                child: Column(
                  children: const [
                    Icon(
                      Icons.calendar_month_rounded,
                      color: AppTheme.textPrimary,
                      size: 48,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Horarios',
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 28,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Consulta tus horarios y clases asignadas',
                      textAlign:
                          TextAlign.center,
                      style: TextStyle(
                        color:
                            AppTheme.textSecondary,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // Estado temporal
              Container(
                width: double.infinity,
                constraints:
                    const BoxConstraints(
                  maxWidth: 850,
                ),
                padding:
                    const EdgeInsets.all(26),
                decoration: BoxDecoration(
                  color: AppTheme.textPrimary,
                  borderRadius:
                      BorderRadius.circular(
                    22,
                  ),
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 18,
                      spreadRadius: 0,
                      offset:
                          const Offset(
                        0,
                        6,
                      ),
                      color:
                          Colors.black12,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      width: 90,
                      height: 90,
                      decoration:
                          BoxDecoration(
                        color: AppTheme.surfaceLight,
                        shape:
                            BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.schedule,
                        size: 42,
                        color: AppTheme.primary,
                      ),
                    ),

                    const SizedBox(
                      height: 22,
                    ),

                    const Text(
                      'Tu horario estará disponible pronto',
                      textAlign:
                          TextAlign.center,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight:
                            FontWeight
                                .bold,
                      ),
                    ),

                    const SizedBox(
                      height: 10,
                    ),

                    Text(
                      'Estamos preparando la integración del sistema de horarios. '
                      'Aquí podrás consultar tus clases, docentes, aulas y horarios asignados.',
                      textAlign:
                          TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors
                            .grey.shade600,
                        height: 1.5,
                      ),
                    ),

                    const SizedBox(
                      height: 28,
                    ),

                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      alignment:
                          WrapAlignment
                              .center,
                      children: [
                        _FeatureChip(
                          icon:
                              Icons.school,
                          label:
                              'Materias',
                        ),
                        _FeatureChip(
                          icon:
                              Icons.person,
                          label:
                              'Docentes',
                        ),
                        _FeatureChip(
                          icon:
                              Icons.meeting_room,
                          label:
                              'Aulas',
                        ),
                        _FeatureChip(
                          icon:
                              Icons.access_time,
                          label:
                              'Horarios',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureChip
    extends StatelessWidget {
  final IconData icon;
  final String label;

  const _FeatureChip({
    required this.icon,
    required this.label,
  });

  @override
  Widget build(
      BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 12,
      ),
      decoration: BoxDecoration(
        color: AppTheme.textPrimary,
        borderRadius:
            BorderRadius.circular(
          16,
        ),
        border: Border.all(
          color:
              AppTheme.surfaceLight,
        ),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 18,
            color:
                AppTheme.primary,
          ),
          const SizedBox(
            width: 8,
          ),
          Text(
            label,
            style: const TextStyle(
              fontWeight:
                  FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

